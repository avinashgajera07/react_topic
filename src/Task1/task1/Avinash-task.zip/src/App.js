import './App.css';
import Task from './Task.jsx'

function App() {
  return (
    <div>
     <Task />
    </div>
  );
}

export default App;
